#!/usr/bin/env python3
"""
generate_dataset.py
=====================================================================
Synthetic Android Forensic Dataset Generator
=====================================================================

This script generates THREE realistic (but fully synthetic/dummy)
SQLite databases that mimic the structure of common Android forensic
artifacts, for use in training, testing, or demoing forensic-analysis
tooling. All names, numbers, messages, URLs, and timestamps are
randomly generated -- none of the data refers to a real person.

Databases produced (in the current working directory):
    1. calllog.db   - mimics Android's CallLog.Calls content provider
    2. mmssms.db    - mimics Android's Telephony.Sms content provider
    3. browser.db   - mimics Android's browser/WebView history table

Run with:
    python generate_dataset.py
"""

import sqlite3
import random
import os
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Global configuration / reproducibility
# ---------------------------------------------------------------------------
random.seed(42)  # fixed seed -> reproducible synthetic data across runs

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

CALLLOG_DB = os.path.join(OUTPUT_DIR, "calllog.db")
MMSSMS_DB = os.path.join(OUTPUT_DIR, "mmssms.db")
BROWSER_DB = os.path.join(OUTPUT_DIR, "browser.db")

# Date range for generated timestamps: 2025-01-01 to 2026-12-31 (UTC)
RANGE_START = int(datetime(2025, 1, 1, tzinfo=timezone.utc).timestamp())
RANGE_END = int(datetime(2026, 12, 31, 23, 59, 59, tzinfo=timezone.utc).timestamp())


def random_unix_timestamp_ms():
    """
    Return a random Unix timestamp in MILLISECONDS (Android convention:
    CallLog.Calls.DATE and Telephony.Sms.DATE are stored in ms since epoch).
    """
    ts_seconds = random.randint(RANGE_START, RANGE_END)
    return ts_seconds * 1000


def random_phone_number():
    """Generate a random synthetic Indian-format mobile number."""
    return f"+91{random.randint(7000000000, 9999999999)}"


# ---------------------------------------------------------------------------
# Synthetic name / contact pools
# ---------------------------------------------------------------------------
FIRST_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Ishaan", "Kabir", "Rohan", "Karan", "Dev",
    "Neha", "Priya", "Ananya", "Isha", "Meera", "Riya", "Sanya", "Tara",
    "Arjun", "Rahul", "Sameer", "Vikram", "Anjali", "Divya", "Pooja", "Sneha",
]
LAST_NAMES = [
    "Sharma", "Verma", "Gupta", "Mehta", "Iyer", "Nair", "Reddy", "Kapoor",
    "Chopra", "Malhotra", "Joshi", "Rao", "Bose", "Kulkarni", "Pillai",
]


def random_contact_name(unknown_ratio=0.15):
    """Return either a synthetic full name, or 'Unknown' style label."""
    if random.random() < unknown_ratio:
        return random.choice([None, "Unknown", "Unsaved Number"])
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


# =====================================================================
# 1. calllog.db  -- Android CallLog.Calls forensic artifact
# =====================================================================
def create_calllog_db(path, num_records=100):
    """
    Creates calllog.db with a single 'calls' table modeled after the
    Android CallLog.Calls content provider schema.

    Columns:
        id       INTEGER PRIMARY KEY AUTOINCREMENT - row id
        number   TEXT    - the phone number involved in the call
        type     INTEGER - call type: 1=Incoming, 2=Outgoing,
                            3=Missed, 4=Rejected  (Android CallLog constants)
        duration INTEGER - call duration in seconds (0 for missed/rejected)
        date     INTEGER - Unix timestamp in milliseconds when call occurred
        name     TEXT    - contact display name (NULL/Unknown if not saved)
    """
    if os.path.exists(path):
        os.remove(path)

    conn = sqlite3.connect(path)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE calls (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            number   TEXT,
            type     INTEGER,   -- 1=Incoming, 2=Outgoing, 3=Missed, 4=Rejected
            duration INTEGER,   -- seconds
            date     INTEGER,   -- unix epoch ms
            name     TEXT
        );
    """)

    # Android CallLog.Calls type constants
    CALL_TYPES = {
        "INCOMING": 1,
        "OUTGOING": 2,
        "MISSED": 3,
        "REJECTED": 4,
    }
    # Weighted distribution of call types (realistic mix)
    type_weights = [
        (CALL_TYPES["INCOMING"], 0.35),
        (CALL_TYPES["OUTGOING"], 0.35),
        (CALL_TYPES["MISSED"], 0.20),
        (CALL_TYPES["REJECTED"], 0.10),
    ]
    types_pool = [t for t, w in type_weights for _ in range(int(w * 100))]

    # Pre-generate a pool of "contacts" so some numbers repeat (realistic)
    contact_pool = [(random_phone_number(), random_contact_name()) for _ in range(25)]

    rows = []
    for _ in range(num_records):
        number, name = random.choice(contact_pool)
        call_type = random.choice(types_pool)

        # Missed / rejected calls have zero duration; others have realistic duration
        if call_type in (CALL_TYPES["MISSED"], CALL_TYPES["REJECTED"]):
            duration = 0
        else:
            duration = random.randint(5, 1800)  # 5 sec to 30 min

        date = random_unix_timestamp_ms()
        rows.append((number, call_type, duration, date, name))

    cur.executemany(
        "INSERT INTO calls (number, type, duration, date, name) VALUES (?, ?, ?, ?, ?);",
        rows,
    )

    conn.commit()
    conn.close()
    print(f"[+] Created {path} with {num_records} call records.")


# =====================================================================
# 2. mmssms.db  -- Android Telephony.Sms forensic artifact
# =====================================================================
def create_mmssms_db(path, num_records=150):
    """
    Creates mmssms.db with a single 'sms' table modeled after the
    Android Telephony.Sms content provider schema.

    Columns:
        id      INTEGER PRIMARY KEY AUTOINCREMENT - row id
        address TEXT    - sender/recipient phone number
        body    TEXT    - message text content
        date    INTEGER - Unix timestamp in milliseconds
        type    INTEGER - message type: 1=Received (inbox), 2=Sent
        read    INTEGER - read status: 0=unread, 1=read
        person  TEXT    - linked contact name (if resolved)
    """
    if os.path.exists(path):
        os.remove(path)

    conn = sqlite3.connect(path)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE sms (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            address TEXT,
            body    TEXT,
            date    INTEGER,   -- unix epoch ms
            type    INTEGER,   -- 1=Received, 2=Sent
            read    INTEGER,   -- 0=unread, 1=read
            person  TEXT
        );
    """)

    SMS_RECEIVED = 1
    SMS_SENT = 2

    # ---- Message templates by forensic category -----------------------
    otp_templates = [
        "Your OTP for login is {otp}. Do not share this with anyone.",
        "{otp} is your verification code for BankSecure App. Valid for 10 minutes.",
        "Use OTP {otp} to complete your transaction. Never share your OTP.",
        "Your one-time password is {otp}. It will expire in 5 minutes.",
    ]
    bank_templates = [
        "INR {amt} debited from A/c XX{acct} on {date_str}. Avl bal INR {bal}.",
        "Your A/c XX{acct} credited with INR {amt} on {date_str}. Info: NEFT transfer.",
        "ALERT: A/c XX{acct} debited INR {amt} at POS terminal. Call 1800-XXX if not you.",
        "EMI of INR {amt} for loan A/c XX{acct} is due on {date_str}.",
    ]
    personal_templates = [
        "Hey, are we still meeting for lunch tomorrow?",
        "Can you send me the notes from today's class?",
        "Happy Birthday! Hope you have a great day 🎉",
        "Running 10 mins late, sorry!",
        "Did you finish the project report?",
        "Let's catch up this weekend, it's been a while.",
        "Thanks for the help earlier, really appreciate it.",
        "Where are you? We're waiting outside.",
        "Call me when you're free, need to discuss something important.",
        "Don't forget to bring the documents tomorrow.",
    ]
    meeting_templates = [
        "Reminder: Team meeting scheduled at {time} today via Zoom.",
        "Your appointment with Dr. {doc} is confirmed for {date_str} at {time}.",
        "Meeting rescheduled to {date_str}, {time}. Please confirm attendance.",
        "Interview scheduled on {date_str} at {time}. Please join 10 mins early.",
    ]
    delivery_templates = [
        "Your order #{order} has been shipped and will arrive by {date_str}.",
        "Your package is out for delivery today. Track: {tracking}",
        "Order #{order} delivered successfully. Rate your experience!",
        "Your order #{order} has been delayed and will now arrive by {date_str}.",
    ]
    suspicious_templates = [
        "Congratulations! You have WON INR 5,00,000. Click http://bit.ly/{code} to claim now.",
        "Your account will be BLOCKED in 24 hrs. Verify KYC now: http://verify-{code}.tk",
        "URGENT: Unusual login detected. Reset password immediately: http://secure-{code}.xyz",
        "You've been selected for a free iPhone! Claim here: http://prize-{code}.info",
        "Limited offer: Loan approved instantly, no docs needed. Reply YES to {phone}",
    ]

    def rand_amt():
        return f"{random.randint(500, 95000):,}"

    def rand_date_str():
        return f"{random.randint(1,28):02d}-{random.randint(1,12):02d}-{random.choice([2025,2026])}"

    def rand_time():
        return f"{random.randint(9,18):02d}:{random.choice(['00','15','30','45'])}"

    def build_message(category):
        if category == "otp":
            return random.choice(otp_templates).format(otp=random.randint(100000, 999999))
        elif category == "bank":
            return random.choice(bank_templates).format(
                amt=rand_amt(), acct=random.randint(1000, 9999),
                date_str=rand_date_str(), bal=rand_amt()
            )
        elif category == "personal":
            return random.choice(personal_templates)
        elif category == "meeting":
            return random.choice(meeting_templates).format(
                time=rand_time(), date_str=rand_date_str(),
                doc=random.choice(LAST_NAMES)
            )
        elif category == "delivery":
            return random.choice(delivery_templates).format(
                order=random.randint(100000, 999999),
                date_str=rand_date_str(),
                tracking=f"TRK{random.randint(100000,999999)}"
            )
        elif category == "suspicious":
            return random.choice(suspicious_templates).format(
                code=random.randint(1000, 9999),
                phone=random_phone_number()
            )
        return "Hello"

    categories = ["otp", "bank", "personal", "meeting", "delivery", "suspicious"]
    # weighted so personal chats dominate a bit, suspicious/otp are rarer
    category_weights = {
        "otp": 15, "bank": 20, "personal": 45, "meeting": 20,
        "delivery": 20, "suspicious": 10,
    }
    weighted_categories = [c for c, w in category_weights.items() for _ in range(w)]

    contact_pool = [(random_phone_number(), random_contact_name()) for _ in range(30)]
    service_numbers = ["BZ-HDFCBK", "VM-ICICIB", "AX-AMAZNO", "VK-SBIBNK", "AD-OTPSMS"]

    rows = []
    for _ in range(num_records):
        category = random.choice(weighted_categories)
        body = build_message(category)
        msg_type = random.choice([SMS_RECEIVED, SMS_SENT])

        # OTP/bank/delivery/suspicious messages are always "received" from service numbers
        if category in ("otp", "bank", "delivery", "suspicious"):
            msg_type = SMS_RECEIVED
            address = random.choice(service_numbers) if category in ("otp", "bank") else random_phone_number()
            person = None
        else:
            address, person = random.choice(contact_pool)

        read = 1 if msg_type == SMS_SENT else random.choice([0, 1])
        date = random_unix_timestamp_ms()

        rows.append((address, body, date, msg_type, read, person))

    cur.executemany(
        "INSERT INTO sms (address, body, date, type, read, person) VALUES (?, ?, ?, ?, ?, ?);",
        rows,
    )

    conn.commit()
    conn.close()
    print(f"[+] Created {path} with {num_records} SMS records.")


# =====================================================================
# 3. browser.db  -- Android browser/WebView history forensic artifact
# =====================================================================
def create_browser_db(path, num_records=200):
    """
    Creates browser.db with a single 'browser_history' table modeled
    after Android's browser/WebView bookmarks-history schema.

    Columns:
        id          INTEGER PRIMARY KEY AUTOINCREMENT - row id
        url         TEXT    - full visited URL
        title       TEXT    - page title as shown in browser
        visit_time  INTEGER - Unix timestamp in milliseconds of visit
        visit_count INTEGER - number of times this URL was visited
    """
    if os.path.exists(path):
        os.remove(path)

    conn = sqlite3.connect(path)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE browser_history (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            url         TEXT,
            title       TEXT,
            visit_time  INTEGER,   -- unix epoch ms
            visit_count INTEGER
        );
    """)

    # (url, title) pairs grouped by forensic-relevant category
    site_pool = [
        # Search engines
        ("https://www.google.com/search?q=cyber+security+tips", "cyber security tips - Google Search"),
        ("https://www.google.com/search?q=weather+today", "weather today - Google Search"),
        ("https://www.bing.com/search?q=android+forensics", "android forensics - Bing"),
        ("https://duckduckgo.com/?q=vpn+free", "vpn free at DuckDuckGo"),

        # Social media
        ("https://www.facebook.com", "Facebook - Log In or Sign Up"),
        ("https://www.instagram.com", "Instagram"),
        ("https://twitter.com/home", "Home / X"),
        ("https://www.whatsapp.com", "WhatsApp"),
        ("https://www.linkedin.com/feed", "LinkedIn Feed"),
        ("https://www.reddit.com/r/androiddev", "Android Dev - Reddit"),

        # Shopping
        ("https://www.amazon.in", "Amazon.in: Online Shopping"),
        ("https://www.flipkart.com", "Flipkart Online Shopping"),
        ("https://www.myntra.com", "Myntra - Fashion Shopping"),
        ("https://www.ebay.com", "Electronics, Cars, Fashion | eBay"),

        # News
        ("https://www.bbc.com/news", "BBC News"),
        ("https://www.ndtv.com", "NDTV News"),
        ("https://timesofindia.indiatimes.com", "Times of India"),
        ("https://www.cnn.com", "CNN"),

        # Educational
        ("https://www.khanacademy.org", "Khan Academy"),
        ("https://www.coursera.org", "Coursera | Online Courses"),
        ("https://www.geeksforgeeks.org", "GeeksforGeeks"),
        ("https://en.wikipedia.org/wiki/Digital_forensics", "Digital forensics - Wikipedia"),

        # Cyber security learning
        ("https://www.hackthebox.com", "Hack The Box"),
        ("https://tryhackme.com", "TryHackMe"),
        ("https://owasp.org", "OWASP Foundation"),
        ("https://github.com", "GitHub"),
        ("https://stackoverflow.com/questions", "Stack Overflow"),
        ("https://www.kali.org", "Kali Linux"),
        ("https://www.exploit-db.com", "Exploit Database"),

        # Banking
        ("https://www.hdfcbank.com/netbanking", "HDFC Bank NetBanking"),
        ("https://www.icicibank.com", "ICICI Bank - Personal Banking"),
        ("https://www.sbi.co.in", "State Bank of India"),
        ("https://www.onlinesbi.sbi", "OnlineSBI Login"),

        # Streaming / entertainment
        ("https://www.youtube.com", "YouTube"),
        ("https://www.netflix.com", "Netflix"),
        ("https://open.spotify.com", "Spotify - Web Player"),

        # Email
        ("https://mail.google.com", "Gmail"),
        ("https://outlook.live.com", "Outlook"),
    ]

    rows = []
    for _ in range(num_records):
        url, title = random.choice(site_pool)
        visit_time = random_unix_timestamp_ms()
        visit_count = random.randint(1, 25)
        rows.append((url, title, visit_time, visit_count))

    cur.executemany(
        "INSERT INTO browser_history (url, title, visit_time, visit_count) VALUES (?, ?, ?, ?);",
        rows,
    )

    conn.commit()
    conn.close()
    print(f"[+] Created {path} with {num_records} browser history records.")


# =====================================================================
# Main entry point
# =====================================================================
def main():
    print("=" * 70)
    print("Synthetic Android Forensic Dataset Generator")
    print("=" * 70)

    create_calllog_db(CALLLOG_DB, num_records=100)
    create_mmssms_db(MMSSMS_DB, num_records=150)
    create_browser_db(BROWSER_DB, num_records=200)

    print("-" * 70)
    print("All databases generated successfully in:")
    print(f"  {OUTPUT_DIR}")
    print("Files:")
    print(f"  - {os.path.basename(CALLLOG_DB)}")
    print(f"  - {os.path.basename(MMSSMS_DB)}")
    print(f"  - {os.path.basename(BROWSER_DB)}")
    print("=" * 70)


if __name__ == "__main__":
    main()
